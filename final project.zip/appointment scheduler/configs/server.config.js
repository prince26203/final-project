/**
 * This file contain the Server configurations
 */
 
module.exports = {
    PORT : 8080
}