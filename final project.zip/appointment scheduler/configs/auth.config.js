module.exports = {
    secret : "This is my super private secret"
}